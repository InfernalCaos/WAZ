const $=s=>document.querySelector(s), root=document.documentElement;
const CK={cmode:'digital',cglow:0,cgauto:true,cgcol:'#78a0ff',cshx:0,cshy:4,cshb:30,cshop:45,cbox:false,cblur:18,crad:28,cbw:1,cbc:'#ffffff',cin:0,cmetal:false,cref:true,cop:100,csm:true,perf:false};
const S=Object.assign({dim:20,blur:14,rot:false,active:null,accent:null,glass:14,clk:true,h24:true,sec:false,font:'system-ui',fsize:96,ss:100,ts:100,fcolor:'#ffffff'},CK,JSON.parse(localStorage.wp||'{}'));
const save=()=>localStorage.wp=JSON.stringify(S);
let toastT;const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('on'),4000)};

/* ---- banco de mídia (IndexedDB) ---- */
const db=new Promise((ok,no)=>{const r=indexedDB.open('wp2',1);r.onupgradeneeded=()=>r.result.createObjectStore('m',{keyPath:'id'});r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)});
const op=async(mode,f)=>{const d=await db;return new Promise((ok,no)=>{const t=d.transaction('m',mode);const rq=f(t.objectStore('m'));t.oncomplete=()=>ok(rq.result);t.onerror=()=>no(t.error)})};
const getAll=()=>op('readonly',s=>s.getAll()), put=r=>op('readwrite',s=>s.put(r)), del=id=>op('readwrite',s=>s.delete(id));
let items=[];

/* ---- exibir wallpaper com crossfade ---- */
let cur=null;
function show(r){
  const old=cur;
  if(!r){if(old){old.classList.remove('on');setTimeout(()=>old.remove(),900);cur=null}return}
  const isVid=r.type.startsWith('video/'), el=document.createElement(isVid?'video':'img');
  el.className='layer';
  const ready=()=>{$('#stage').append(el);requestAnimationFrame(()=>el.classList.add('on'));cur=el;
    if(old){old.classList.remove('on');setTimeout(()=>{URL.revokeObjectURL(old.src);old.remove()},1000)}};
  if(isVid){Object.assign(el,{muted:true,loop:true,autoplay:true,playsInline:true,preload:'auto',disablePictureInPicture:true,disableRemotePlayback:true});
    el.onloadeddata=()=>{ready();el.play().catch(()=>{})};
    el.onerror=()=>toast('Este vídeo não pôde ser reproduzido. Use MP4 (H.264) ou WebM.');
  }else el.onload=ready;
  el.src=URL.createObjectURL(r.blob);
}
const activeRec=()=>items.find(i=>i.id===S.active)||items[0];

/* ---- importar arquivos ---- */
function thumbOf(f){return new Promise(ok=>{
  if(f.type.startsWith('image/'))return ok('');
  const v=document.createElement('video');v.muted=true;v.preload='auto';v.src=URL.createObjectURL(f);
  v.onloadeddata=()=>{v.currentTime=Math.min(1,(v.duration||2)/2)};
  v.onseeked=()=>{const c=document.createElement('canvas');c.width=192;c.height=120;
    c.getContext('2d').drawImage(v,0,0,192,120);URL.revokeObjectURL(v.src);ok(c.toDataURL('image/jpeg',.7))};
  v.onerror=()=>ok(null);
})}
async function addFiles(files){
  let last;
  for(const f of files){
    if(!/^(video|image)\//.test(f.type)){toast('Arquivo ignorado: '+f.name);continue}
    const th=await thumbOf(f);
    if(th===null){toast('Formato de vídeo não suportado. Converta para MP4 (H.264) ou WebM.');continue}
    last={id:Date.now()+Math.random(),name:f.name,type:f.type,blob:f,thumb:th};
    await put(last);items.push(last);
  }
  if(last){S.active=last.id;save();show(last);render()}
}

/* ---- galeria ---- */
function render(){
  const lib=$('#lib');lib.innerHTML='';
  items.forEach(r=>{
    const d=document.createElement('div');d.className='th'+(r.id===S.active?' act':'');
    d.style.backgroundImage=`url(${r.thumb||URL.createObjectURL(r.blob)})`;d.title=r.name;
    d.onclick=()=>{S.active=r.id;save();show(r);render()};
    const x=document.createElement('b');x.textContent='✕';
    x.onclick=async e=>{e.stopPropagation();await del(r.id);items=items.filter(i=>i.id!==r.id);
      if(S.active===r.id){S.active=items[0]?.id||null;save();show(activeRec())}render()};
    d.append(x);lib.append(d)});
}

/* ---- painel / controles ---- */
$('#gear').onclick=()=>document.body.classList.toggle('open');
addEventListener('keydown',e=>{if(e.key==='Escape')document.body.classList.remove('open')});
$('#add').onclick=()=>$('#file').click();
$('#file').onchange=e=>{addFiles([...e.target.files]);e.target.value=''};
['dragenter','dragover'].forEach(t=>addEventListener(t,e=>{e.preventDefault();document.body.classList.add('drag')}));
addEventListener('dragleave',e=>{if(!e.relatedTarget)document.body.classList.remove('drag')});
addEventListener('drop',e=>{e.preventDefault();document.body.classList.remove('drag');addFiles([...e.dataTransfer.files])});
const clk=$('#clock'),fs=$('#font'),hex2rgb=h=>[1,3,5].map(i=>parseInt(h.substr(i,2),16)).join(' ');
function tick(){tickA();const d=new Date(),o={hour:'2-digit',minute:'2-digit',hour12:!S.h24};if(S.sec)o.second='2-digit';
  $('#hm').textContent=d.toLocaleTimeString('pt-BR',o);$('#dt').textContent=d.toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long'})}

function applyCfg(){root.style.setProperty('--dim',S.dim/100);root.style.setProperty('--blur',S.blur+'px');root.style.setProperty('--glass',S.glass/100);
  if(S.accent)root.style.setProperty('--accent',hex2rgb(S.accent));
  clk.style.display=S.clk?'':'none';clk.style.fontFamily=`"${S.font}",system-ui,sans-serif`;root.style.setProperty('--ss',S.ss/100);root.style.setProperty('--ts',S.ts/100);clk.style.fontSize=`min(${S.fsize}px,16vw)`;clk.style.color=S.fcolor;document.body.classList.toggle('perf',S.perf);clockFx();tick()}
const bind=(id,k)=>{const e=$('#'+id),c=e.type==='checkbox';e[c?'checked':'value']=S[k];
  e.oninput=()=>{S[k]=c?e.checked:e.type==='range'?+e.value:e.value;save();applyCfg()}};
['glass','clk','h24','sec','fsize','fcolor','ss','ts'].forEach(k=>bind(k,k));
$('#glass').value=S.glass;
$('#rst').onclick=()=>{Object.assign(S,{ss:100,ts:100,fsize:96});['ss','ts','fsize'].forEach(k=>$('#'+k).value=S[k]);save();applyCfg();toast('Tamanhos restaurados')};
/* relógio avançado */
const SPEC=[['h','Estilo do relógio'],['cmode','Estilo','sel',['digital:Digital','analog:Analógico']],['cmetal','Texto metálico (gradiente)','c'],['cop','Opacidade','r',10,100],['csm','Ponteiros com movimento suave','c'],
['h','Brilho neon'],['cglow','Intensidade','r',0,60],['cgauto','Brilho segue a cor do tema','c'],['cgcol','Cor do brilho','col'],
['h','Sombra projetada'],['cshx','Horizontal','r',-40,40],['cshy','Vertical','r',-40,40],['cshb','Desfoque','r',0,80],['cshop','Opacidade da sombra','r',0,100],
['h','Moldura de vidro'],['cbox','Mostrar moldura','c'],['cblur','Desfoque do vidro','r',0,40],['crad','Arredondamento','r',0,120],['cbw','Espessura da borda','r',0,8],['cbc','Cor da borda','col'],['cin','Sombra interna','r',0,50],['cref','Reflexo no vidro','c'],
['h','Fluidez'],['perf','Modo desempenho (vídeo mais fluido)','c'],['h','Google Fonts (opcional)'],['gf']];
const adv=$('#advbody');
SPEC.forEach(([id,l,t,a,b])=>{
  if(id==='h'){const h=document.createElement('h5');h.textContent=l;return adv.append(h)}
  if(id==='gf'){const r=document.createElement('div');r.className='two';r.innerHTML='<input id="gfin" placeholder="Ex.: Orbitron"><button id="gfb">Aplicar</button>';
    const p=document.createElement('p');p.className='hint';p.textContent='Requer internet: o navegador baixa a fonte do Google.';return adv.append(r,p)}
  const lab=document.createElement('label'),i=document.createElement(t==='sel'?'select':'input');i.id=id;
  if(t==='sel')a.forEach(o=>{const[v,x]=o.split(':');i.append(new Option(x,v))});
  else{i.type=t==='r'?'range':t==='c'?'checkbox':'color';if(t==='r'){i.min=a;i.max=b}}
  const row=t==='c'||t==='col';if(row)lab.className='row';lab.append(...(row?[i,' '+l]:[l,i]));adv.append(lab)});
Object.keys(CK).forEach(k=>bind(k,k));
$('#crst').onclick=()=>{Object.assign(S,CK);Object.keys(CK).forEach(k=>{const e=$('#'+k);e[e.type==='checkbox'?'checked':'value']=S[k]});save();applyCfg();toast('Efeitos restaurados')};
function gfont(n,quiet){n=n.trim().replace(/[^\w\s]/g,'');if(!n)return;const l=document.createElement('link');l.rel='stylesheet';
  l.href='https://fonts.googleapis.com/css2?family='+encodeURIComponent(n).replace(/%20/g,'+')+'&display=swap';
  l.onload=()=>{S.font=n;S.gf=n;save();addOpt(n,'web');applyCfg();quiet||toast('Fonte aplicada: '+n)};
  l.onerror=()=>{l.remove();quiet||toast('Fonte não encontrada no Google Fonts (ou sem internet).')};document.head.append(l)}
$('#gfb').onclick=()=>gfont($('#gfin').value);$('#gfin').onkeydown=e=>{if(e.key==='Enter')gfont(e.target.value)};
if(S.gf)gfont(S.gf,1);
const hexA=(h,a)=>`rgba(${hex2rgb(h).replaceAll(' ',',')},${a})`;
function clockFx(){
  const an=S.cmode==='analog',g=S.cglow,gc=S.cgauto?'rgb(var(--accent))':S.cgcol,sc=`rgba(0,0,0,${S.cshop/100})`,hm=$('#hm'),cb=$('#cbox'),A=$('#analog');
  const ts=(g?[g/4,g/2,g].map(x=>`0 0 ${x}px ${gc}`).join(',')+',':'')+`${S.cshx}px ${S.cshy}px ${S.cshb}px ${sc}`;
  const fl=(g?`drop-shadow(0 0 ${g/3}px ${gc}) drop-shadow(0 0 ${g}px ${gc}) `:'')+`drop-shadow(${S.cshx}px ${S.cshy}px ${S.cshb/2}px ${sc})`;
  hm.classList.toggle('metal',S.cmetal);hm.style.textShadow=S.cmetal?'none':ts;hm.style.filter=S.cmetal?fl:'none';
  hm.style.display=an?'none':'';A.style.display=an?'':'none';A.style.filter=fl;A.classList.toggle('sm',S.csm&&!!clockFx.r);
  A.style.width=A.style.height=`min(${Math.min(S.fsize*2.4,600)}px,60vmin)`;
  const on=S.cbox||an;cb.className=on?(an?'on an':'on'):'';
  cb.style.cssText=on?`border-radius:${an?'50%':S.crad+'px'};border:${S.cbw}px solid ${hexA(S.cbc,.4)};backdrop-filter:blur(${S.cblur}px) saturate(1.4);`+
   `background:${S.cref?'radial-gradient(120% 90% at 25% 8%,rgba(255,255,255,.3),transparent 55%),linear-gradient(135deg,rgba(255,255,255,.14),rgba(255,255,255,.04))':'rgba(255,255,255,.1)'};`+
   `box-shadow:0 16px 44px rgba(0,0,0,.3),inset 0 ${S.cin/3}px ${S.cin}px rgba(255,255,255,.3),inset 0 -${S.cin/3}px ${S.cin}px rgba(0,0,0,.28)`:'';
  clk.style.opacity=S.cop/100}
const lt=()=>Date.now()/1000-new Date().getTimezoneOffset()*60,T0=lt(),Hd=[...'hms'].map(c=>$('#analog .'+c));
function tickA(){if($('#analog').style.display==='none')return;const t=lt(),f=Math.floor,m=(x,k)=>(x*k)%360;
  const a=[m(T0,1/120)+(t-T0)/120,S.csm?m(T0,.1)+(t-T0)*.1:m(f(T0/60),6)+(f(t/60)-f(T0/60))*6,m(f(T0),6)+(f(t)-f(T0))*6];
  Hd.forEach((h,i)=>h.style.transform=`rotate(${a[i]}deg)`)}
(function lp(){tick();setTimeout(lp,1000-Date.now()%1000)})();
setTimeout(()=>{clockFx.r=1;clockFx()},150);
let lq=[0,0];setInterval(()=>{if(S.perf||!cur||cur.tagName!=='VIDEO'||document.hidden||!cur.getVideoPlaybackQuality)return;
  const q=cur.getVideoPlaybackQuality(),d=q.droppedVideoFrames-lq[0],t=q.totalVideoFrames-lq[1];lq=[q.droppedVideoFrames,q.totalVideoFrames];
  if(d<0||t<0){lq=[0,0];return}if(t>60&&d/t>.15){S.perf=true;save();applyCfg();$('#perf').checked=true;toast('Modo desempenho ativado automaticamente para o vídeo ficar mais fluido.')}},4000);
/* cores */
const ac=$('#accent');ac.value=S.accent||'#78a0ff';
ac.oninput=()=>{S.accent=ac.value;save();applyCfg()};
$('#auto').onclick=()=>{S.accent=null;save();toast('Cor automática: segue as cores do vídeo')};
['#78a0ff','#ff5bd1','#35e0c4','#ffb347','#ff5b5b','#b388ff','#ffffff'].forEach(c=>{const i=document.createElement('i');
  i.style.background=c;i.onclick=()=>{S.accent=c;ac.value=c;save();applyCfg()};$('#sw').append(i)});
/* fontes */
[['std','Padrão'],['up','Enviadas'],['web','Google Fonts'],['pc','Do computador']].forEach(([k,l])=>{const g=document.createElement('optgroup');g.label=l;g.dataset.g=k;fs.append(g)});
function addOpt(n,g){if(![...fs.options].some(o=>o.value===n)){const o=new Option(n,n);o.style.fontFamily=n;fs.querySelector(`[data-g=${g}]`).append(o)}fs.value=S.font}
['system-ui','Segoe UI','Georgia','Trebuchet MS','Impact','Courier New','Brush Script MT'].forEach(n=>addOpt(n,'std'));
addOpt(S.font,'pc');fs.onchange=()=>{S.font=fs.value;save();applyCfg()};
async function regFont(r){const f=new FontFace(r.name,await r.blob.arrayBuffer());await f.load();document.fonts.add(f);addOpt(r.name,'up')}
$('#upf').onclick=()=>$('#ffile').click();
$('#ffile').onchange=async e=>{for(const f of e.target.files){const r={id:'font:'+f.name,font:true,name:f.name.replace(/\.[^.]+$/,''),blob:f};
  await put(r);S.font=r.name;await regFont(r)}e.target.value='';save();applyCfg()};
if(!window.queryLocalFonts)$('#pcf').style.display='none';
$('#pcf').onclick=async()=>{try{const l=await queryLocalFonts();[...new Set(l.map(f=>f.family))].sort().forEach(n=>addOpt(n,'pc'));
  fs.value=S.font;toast('Fontes do computador carregadas: escolha na lista')}catch{toast('Permissão negada para ler as fontes do computador.')}};
$('#dim').value=S.dim;$('#blur').value=S.blur;$('#rot').checked=S.rot;applyCfg();
$('#dim').oninput=e=>{S.dim=+e.target.value;save();applyCfg()};
$('#blur').oninput=e=>{S.blur=+e.target.value;save();applyCfg()};
$('#rot').onchange=e=>{S.rot=e.target.checked;save()};
setInterval(()=>{if(S.rot&&items.length>1&&!document.hidden){
  const i=items.findIndex(x=>x.id===S.active);const n=items[(i+1)%items.length];S.active=n.id;save();show(n);render()}},120000);

/* ---- efeitos: parallax, cor dinâmica, economia de bateria ---- */
let mx=0,my=0,raf=0;addEventListener('mousemove',e=>{if(S.perf||raf)return;mx=(e.clientX/innerWidth-.5)*-14;my=(e.clientY/innerHeight-.5)*-14;
  raf=requestAnimationFrame(()=>{raf=0;$('#stage').style.transform=`translate3d(${mx}px,${my}px,0) scale(1.02)`})});
const cv=document.createElement('canvas');cv.width=cv.height=8;const cx=cv.getContext('2d',{willReadFrequently:true});
setInterval(()=>{if(S.accent||!cur||document.hidden)return;try{cx.drawImage(cur,0,0,8,8);const d=cx.getImageData(0,0,8,8).data;
  let r=0,g=0,b=0;for(let i=0;i<d.length;i+=4){r+=d[i];g+=d[i+1];b+=d[i+2]}const n=d.length/4;
  const m=Math.max(r,g,b)/n||1,k=Math.min(1.8,200/m);   // realça a cor para brilhar no vidro
  root.style.setProperty('--accent',[r,g,b].map(c=>Math.min(255,c/n*k|0)).join(' '))}catch{}},5000);
document.addEventListener('visibilitychange',()=>{if(cur&&cur.tagName==='VIDEO')document.hidden?cur.pause():cur.play().catch(()=>{})});

/* ---- busca e atalhos do Chrome ---- */
const q=$('#q');
q.onfocus=()=>document.body.classList.add('searching');
q.onblur=()=>document.body.classList.remove('searching');
q.onkeydown=e=>{if(e.key!=='Enter')return;const v=q.value.trim();if(!v)return;
  const isUrl=!/\s/.test(v)&&/^(https?:\/\/|[\w-]+(\.[\w-]+)+(\/|:|$))/i.test(v);
  if(isUrl)location.href=/^https?:\/\//i.test(v)?v:'https://'+v;
  else try{(FF?browser.search.search({query:v,disposition:'CURRENT_TAB'}):chrome.search.query({text:v,disposition:'CURRENT_TAB'}))?.catch?.(()=>{})}
  catch{location.href='https://www.google.com/search?q='+encodeURIComponent(v)}};
const FF=typeof browser!=='undefined'&&/Firefox\//.test(navigator.userAgent);
async function getTop(){try{if(FF)return await browser.topSites.get({includeFavicon:true})}catch{}
  return new Promise((ok,no)=>{try{chrome.topSites.get(l=>chrome.runtime.lastError?no():ok(l||[]))}catch(e){no(e)}})}
getTop().then(list=>list.slice(0,8).forEach(s=>{
  const a=document.createElement('a');a.className='tile';a.href=s.url;
  const ic=FF?(s.favicon||''):chrome.runtime.getURL('/_favicon/')+'?pageUrl='+encodeURIComponent(s.url)+'&size=32';
  const ii=document.createElement('i'),im0=document.createElement('img'),sp=document.createElement('span');if(ic)im0.src=ic;ii.append(im0);
  sp.textContent=s.title||(()=>{try{return new URL(s.url).hostname}catch{return s.url}})();a.append(ii,sp);
  const im=a.querySelector('img'),fb=()=>im.replaceWith(Object.assign(document.createElement('b'),{textContent:(s.title||s.url.replace(/^\w+:\/\//,'')||'?')[0].toUpperCase()}));im.onerror=fb;if(!ic)fb();
  $('#tiles').append(a)})).catch(()=>{});

/* ---- iniciar ---- */
try{$('#ver').textContent='WAZ · Glass v'+chrome.runtime.getManifest().version}catch{}
getAll().then(r=>{items=r.filter(x=>!x.font);r.filter(x=>x.font).forEach(regFont);show(activeRec());render()});
