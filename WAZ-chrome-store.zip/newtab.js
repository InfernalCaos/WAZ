const $=s=>document.querySelector(s), root=document.documentElement;
const S=Object.assign({dim:20,blur:14,rot:false,active:null,accent:null,glass:14,clk:true,h24:true,sec:false,font:'system-ui',fsize:96,ss:100,ts:100,fcolor:'#ffffff'},JSON.parse(localStorage.wp||'{}'));
const save=()=>localStorage.wp=JSON.stringify(S);
let toastT;const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('on'),4000)};

/* ---- banco de mídia (IndexedDB) ---- */
const db=new Promise((ok,no)=>{const r=indexedDB.open('wp2',1);r.onupgradeneeded=()=>r.result.createObjectStore('m',{keyPath:'id'});r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)});
const op=async(mode,f)=>{const d=await db;return new Promise((ok,no)=>{const t=d.transaction('m',mode);const rq=f(t.objectStore('m'));t.oncomplete=()=>ok(rq.result);t.onerror=()=>no(t.error)})};
const getAll=()=>op('readonly',s=>s.getAll()), put=r=>op('readwrite',s=>s.put(r)), del=id=>op('readwrite',s=>s.delete(id));
let items=[];

/* ---- exibir wallpaper com crossfade ---- */
let cur=null;
function show(r){
  const old=cur;
  if(!r){if(old){old.classList.remove('on');setTimeout(()=>old.remove(),900);cur=null}return}
  const isVid=r.type.startsWith('video/'), el=document.createElement(isVid?'video':'img');
  el.className='layer';
  const ready=()=>{$('#stage').append(el);requestAnimationFrame(()=>el.classList.add('on'));cur=el;
    if(old){old.classList.remove('on');setTimeout(()=>{URL.revokeObjectURL(old.src);old.remove()},1000)}};
  if(isVid){Object.assign(el,{muted:true,loop:true,autoplay:true,playsInline:true});
    el.onloadeddata=()=>{ready();el.play().catch(()=>{})};
    el.onerror=()=>toast('Este vídeo não pôde ser reproduzido. Use MP4 (H.264) ou WebM.');
  }else el.onload=ready;
  el.src=URL.createObjectURL(r.blob);
}
const activeRec=()=>items.find(i=>i.id===S.active)||items[0];

/* ---- importar arquivos ---- */
function thumbOf(f){return new Promise(ok=>{
  if(f.type.startsWith('image/'))return ok('');
  const v=document.createElement('video');v.muted=true;v.preload='auto';v.src=URL.createObjectURL(f);
  v.onloadeddata=()=>{v.currentTime=Math.min(1,(v.duration||2)/2)};
  v.onseeked=()=>{const c=document.createElement('canvas');c.width=192;c.height=120;
    c.getContext('2d').drawImage(v,0,0,192,120);URL.revokeObjectURL(v.src);ok(c.toDataURL('image/jpeg',.7))};
  v.onerror=()=>ok(null);
})}
async function addFiles(files){
  let last;
  for(const f of files){
    if(!/^(video|image)\//.test(f.type)){toast('Arquivo ignorado: '+f.name);continue}
    const th=await thumbOf(f);
    if(th===null){toast('Formato de vídeo não suportado. Converta para MP4 (H.264) ou WebM.');continue}
    last={id:Date.now()+Math.random(),name:f.name,type:f.type,blob:f,thumb:th};
    await put(last);items.push(last);
  }
  if(last){S.active=last.id;save();show(last);render()}
}

/* ---- galeria ---- */
function render(){
  const lib=$('#lib');lib.innerHTML='';
  items.forEach(r=>{
    const d=document.createElement('div');d.className='th'+(r.id===S.active?' act':'');
    d.style.backgroundImage=`url(${r.thumb||URL.createObjectURL(r.blob)})`;d.title=r.name;
    d.onclick=()=>{S.active=r.id;save();show(r);render()};
    const x=document.createElement('b');x.textContent='✕';
    x.onclick=async e=>{e.stopPropagation();await del(r.id);items=items.filter(i=>i.id!==r.id);
      if(S.active===r.id){S.active=items[0]?.id||null;save();show(activeRec())}render()};
    d.append(x);lib.append(d)});
}

/* ---- painel / controles ---- */
$('#gear').onclick=()=>document.body.classList.toggle('open');
addEventListener('keydown',e=>{if(e.key==='Escape')document.body.classList.remove('open')});
$('#add').onclick=()=>$('#file').click();
$('#file').onchange=e=>{addFiles([...e.target.files]);e.target.value=''};
['dragenter','dragover'].forEach(t=>addEventListener(t,e=>{e.preventDefault();document.body.classList.add('drag')}));
addEventListener('dragleave',e=>{if(!e.relatedTarget)document.body.classList.remove('drag')});
addEventListener('drop',e=>{e.preventDefault();document.body.classList.remove('drag');addFiles([...e.dataTransfer.files])});
const clk=$('#clock'),fs=$('#font'),hex2rgb=h=>[1,3,5].map(i=>parseInt(h.substr(i,2),16)).join(' ');
function tick(){const d=new Date(),o={hour:'2-digit',minute:'2-digit',hour12:!S.h24};if(S.sec)o.second='2-digit';
  $('#hm').textContent=d.toLocaleTimeString('pt-BR',o);$('#dt').textContent=d.toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long'})}
setInterval(tick,1000);
function applyCfg(){root.style.setProperty('--dim',S.dim/100);root.style.setProperty('--blur',S.blur+'px');root.style.setProperty('--glass',S.glass/100);
  if(S.accent)root.style.setProperty('--accent',hex2rgb(S.accent));
  clk.style.display=S.clk?'':'none';clk.style.fontFamily=`"${S.font}",system-ui,sans-serif`;root.style.setProperty('--ss',S.ss/100);root.style.setProperty('--ts',S.ts/100);clk.style.fontSize=`min(${S.fsize}px,16vw)`;clk.style.color=S.fcolor;tick()}
const bind=(id,k)=>{const e=$('#'+id),c=e.type==='checkbox';e[c?'checked':'value']=S[k];
  e.oninput=()=>{S[k]=c?e.checked:e.type==='range'?+e.value:e.value;save();applyCfg()}};
['glass','clk','h24','sec','fsize','fcolor','ss','ts'].forEach(k=>bind(k,k));
$('#glass').value=S.glass;
$('#rst').onclick=()=>{Object.assign(S,{ss:100,ts:100,fsize:96});['ss','ts','fsize'].forEach(k=>$('#'+k).value=S[k]);save();applyCfg();toast('Tamanhos restaurados')};
/* cores */
const ac=$('#accent');ac.value=S.accent||'#78a0ff';
ac.oninput=()=>{S.accent=ac.value;save();applyCfg()};
$('#auto').onclick=()=>{S.accent=null;save();toast('Cor automática: segue as cores do vídeo')};
['#78a0ff','#ff5bd1','#35e0c4','#ffb347','#ff5b5b','#b388ff','#ffffff'].forEach(c=>{const i=document.createElement('i');
  i.style.background=c;i.onclick=()=>{S.accent=c;ac.value=c;save();applyCfg()};$('#sw').append(i)});
/* fontes */
[['std','Padrão'],['up','Enviadas'],['pc','Do computador']].forEach(([k,l])=>{const g=document.createElement('optgroup');g.label=l;g.dataset.g=k;fs.append(g)});
function addOpt(n,g){if(![...fs.options].some(o=>o.value===n)){const o=new Option(n,n);o.style.fontFamily=n;fs.querySelector(`[data-g=${g}]`).append(o)}fs.value=S.font}
['system-ui','Segoe UI','Georgia','Trebuchet MS','Impact','Courier New','Brush Script MT'].forEach(n=>addOpt(n,'std'));
addOpt(S.font,'pc');fs.onchange=()=>{S.font=fs.value;save();applyCfg()};
async function regFont(r){const f=new FontFace(r.name,await r.blob.arrayBuffer());await f.load();document.fonts.add(f);addOpt(r.name,'up')}
$('#upf').onclick=()=>$('#ffile').click();
$('#ffile').onchange=async e=>{for(const f of e.target.files){const r={id:'font:'+f.name,font:true,name:f.name.replace(/\.[^.]+$/,''),blob:f};
  await put(r);S.font=r.name;await regFont(r)}e.target.value='';save();applyCfg()};
$('#pcf').onclick=async()=>{try{const l=await queryLocalFonts();[...new Set(l.map(f=>f.family))].sort().forEach(n=>addOpt(n,'pc'));
  fs.value=S.font;toast('Fontes do computador carregadas: escolha na lista')}catch{toast('Permissão negada para ler as fontes do computador.')}};
$('#dim').value=S.dim;$('#blur').value=S.blur;$('#rot').checked=S.rot;applyCfg();
$('#dim').oninput=e=>{S.dim=+e.target.value;save();applyCfg()};
$('#blur').oninput=e=>{S.blur=+e.target.value;save();applyCfg()};
$('#rot').onchange=e=>{S.rot=e.target.checked;save()};
setInterval(()=>{if(S.rot&&items.length>1&&!document.hidden){
  const i=items.findIndex(x=>x.id===S.active);const n=items[(i+1)%items.length];S.active=n.id;save();show(n);render()}},120000);

/* ---- efeitos: parallax, cor dinâmica, economia de bateria ---- */
addEventListener('mousemove',e=>{const x=(e.clientX/innerWidth-.5)*-14,y=(e.clientY/innerHeight-.5)*-14;
  $('#stage').style.transform=`translate(${x}px,${y}px) scale(1.02)`});
const cv=document.createElement('canvas');cv.width=cv.height=8;const cx=cv.getContext('2d',{willReadFrequently:true});
setInterval(()=>{if(S.accent||!cur||document.hidden)return;try{cx.drawImage(cur,0,0,8,8);const d=cx.getImageData(0,0,8,8).data;
  let r=0,g=0,b=0;for(let i=0;i<d.length;i+=4){r+=d[i];g+=d[i+1];b+=d[i+2]}const n=d.length/4;
  const m=Math.max(r,g,b)/n||1,k=Math.min(1.8,200/m);   // realça a cor para brilhar no vidro
  root.style.setProperty('--accent',[r,g,b].map(c=>Math.min(255,c/n*k|0)).join(' '))}catch{}},1500);
document.addEventListener('visibilitychange',()=>{if(cur&&cur.tagName==='VIDEO')document.hidden?cur.pause():cur.play().catch(()=>{})});

/* ---- busca e atalhos do Chrome ---- */
const q=$('#q');
q.onfocus=()=>document.body.classList.add('searching');
q.onblur=()=>document.body.classList.remove('searching');
q.onkeydown=e=>{if(e.key!=='Enter')return;const v=q.value.trim();if(!v)return;
  const isUrl=!/\s/.test(v)&&/^(https?:\/\/|[\w-]+(\.[\w-]+)+(\/|:|$))/i.test(v);
  if(isUrl)location.href=/^https?:\/\//i.test(v)?v:'https://'+v;
  else chrome.search.query({text:v,disposition:'CURRENT_TAB'})};
chrome.topSites.get(list=>list.slice(0,8).forEach(s=>{
  const a=document.createElement('a');a.className='tile';a.href=s.url;
  const ic=chrome.runtime.getURL('/_favicon/')+'?pageUrl='+encodeURIComponent(s.url)+'&size=32';
  a.innerHTML=`<i><img src="${ic}"></i><span></span>`;a.querySelector('span').textContent=s.title||new URL(s.url).hostname;
  $('#tiles').append(a)}));

/* ---- iniciar ---- */
getAll().then(r=>{items=r.filter(x=>!x.font);r.filter(x=>x.font).forEach(regFont);show(activeRec());render()});
